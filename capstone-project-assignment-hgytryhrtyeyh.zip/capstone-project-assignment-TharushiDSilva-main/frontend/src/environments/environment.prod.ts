export const environment = {
  production: true,
  name: 'dev',
  test: false
};
